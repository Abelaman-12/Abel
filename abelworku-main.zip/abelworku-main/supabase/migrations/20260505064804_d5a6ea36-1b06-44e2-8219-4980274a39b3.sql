
-- Gallery: support videos
ALTER TABLE public.gallery_items
  ADD COLUMN IF NOT EXISTS media_type TEXT NOT NULL DEFAULT 'image',
  ADD COLUMN IF NOT EXISTS video_url TEXT;

-- Certificates
CREATE TABLE IF NOT EXISTS public.certificates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  issuer TEXT,
  year TEXT,
  image_url TEXT NOT NULL,
  link TEXT,
  created_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.certificates ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone view certificates" ON public.certificates FOR SELECT USING (true);
CREATE POLICY "Admins manage certificates" ON public.certificates FOR ALL TO authenticated
  USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));

-- News
CREATE TABLE IF NOT EXISTS public.news_posts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  content TEXT,
  media_url TEXT,
  media_type TEXT DEFAULT 'image',
  created_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.news_posts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone view news" ON public.news_posts FOR SELECT USING (true);
CREATE POLICY "Admins manage news" ON public.news_posts FOR ALL TO authenticated
  USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));

-- Contact attachments + location
ALTER TABLE public.contact_messages
  ADD COLUMN IF NOT EXISTS attachment_url TEXT,
  ADD COLUMN IF NOT EXISTS location TEXT;

-- Profile country
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS country TEXT;

-- Portfolio settings (single row)
CREATE TABLE IF NOT EXISTS public.portfolio_settings (
  id INT PRIMARY KEY DEFAULT 1,
  hero_name TEXT NOT NULL DEFAULT 'Abel Worku',
  tagline TEXT NOT NULL DEFAULT 'Crafting precision in the markets and creativity on screen.',
  bio TEXT,
  profile_image_url TEXT,
  experience_text TEXT NOT NULL DEFAULT '1.5+ Years',
  stat_disciplines TEXT NOT NULL DEFAULT '5',
  stat_projects TEXT NOT NULL DEFAULT '100+',
  stat_ideas TEXT NOT NULL DEFAULT '∞',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT single_row CHECK (id = 1)
);
INSERT INTO public.portfolio_settings (id) VALUES (1) ON CONFLICT DO NOTHING;
ALTER TABLE public.portfolio_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone read settings" ON public.portfolio_settings FOR SELECT USING (true);
CREATE POLICY "Admin update settings" ON public.portfolio_settings FOR UPDATE TO authenticated
  USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));
CREATE POLICY "Admin insert settings" ON public.portfolio_settings FOR INSERT TO authenticated
  WITH CHECK (has_role(auth.uid(),'admin'));

-- Error logs
CREATE TABLE IF NOT EXISTS public.error_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  page TEXT,
  message TEXT NOT NULL,
  stack TEXT,
  user_agent TEXT,
  user_id UUID,
  resolved BOOLEAN NOT NULL DEFAULT false,
  resolution_note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.error_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone log errors" ON public.error_logs FOR INSERT WITH CHECK (true);
CREATE POLICY "Admin view errors" ON public.error_logs FOR SELECT TO authenticated USING (has_role(auth.uid(),'admin'));
CREATE POLICY "Admin update errors" ON public.error_logs FOR UPDATE TO authenticated USING (has_role(auth.uid(),'admin'));
CREATE POLICY "Admin delete errors" ON public.error_logs FOR DELETE TO authenticated USING (has_role(auth.uid(),'admin'));

-- Storage buckets
INSERT INTO storage.buckets (id, name, public) VALUES ('media','media',true) ON CONFLICT DO NOTHING;
INSERT INTO storage.buckets (id, name, public) VALUES ('message-attachments','message-attachments',true) ON CONFLICT DO NOTHING;

-- Storage policies
CREATE POLICY "Public read media" ON storage.objects FOR SELECT USING (bucket_id = 'media');
CREATE POLICY "Admin upload media" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'media' AND has_role(auth.uid(),'admin'));
CREATE POLICY "Admin delete media" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'media' AND has_role(auth.uid(),'admin'));

CREATE POLICY "Public read attachments" ON storage.objects FOR SELECT USING (bucket_id = 'message-attachments');
CREATE POLICY "Anyone upload attachment" ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'message-attachments');

-- Update handle_new_user to capture country
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, age, referral_source, country)
  VALUES (
    NEW.id, NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name'),
    NULLIF(NEW.raw_user_meta_data->>'age','')::INTEGER,
    NEW.raw_user_meta_data->>'referral_source',
    NEW.raw_user_meta_data->>'country'
  );
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'user') ON CONFLICT DO NOTHING;
  IF NEW.email = 'abelw4123@gmail.com' THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin') ON CONFLICT DO NOTHING;
  END IF;
  RETURN NEW;
END; $$;
