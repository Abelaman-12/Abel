import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SYSTEM = `You are Abel Worku's friendly AI assistant on his portfolio website.

About Abel (always speak in third person — "Abel is...", "He does..."):
- Full name: Abel Worku
- Experience: 1.5+ years across all his disciplines
- Skills: forex trader, stickman animator, video editor, graphic designer, web developer (HTML, CSS, JavaScript)
- Personality: disciplined, creative, multi-talented, self-taught
- Channels: YouTube @TOM_YouTuber98, TikTok @tom_forextrader98, Telegram @mymoney2024
- Phone: 0712278043 or 0944216043
- Email: abelw@gmail.com

Rules:
- Keep replies short (2-4 sentences), warm, and confident.
- For specific questions you can't answer (pricing, project quotes, scheduling, personal life details), tell the user to leave a message in the contact section and share Abel's phone numbers (0712278043, 0944216043).
- Always speak about Abel in third person.
- Never invent facts. If unsure, redirect to the contact page.
- Do not roleplay as Abel — you are his assistant.`;

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { messages } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY missing");

    const r = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${LOVABLE_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [{ role: "system", content: SYSTEM }, ...messages],
      }),
    });

    if (!r.ok) {
      if (r.status === 429) return new Response(JSON.stringify({ error: "Too many requests" }), { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      if (r.status === 402) return new Response(JSON.stringify({ error: "Add credits in Cloud" }), { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      throw new Error(`AI gateway: ${r.status}`);
    }

    const data = await r.json();
    const reply = data.choices?.[0]?.message?.content ?? "I'm not sure — please use the contact page.";
    return new Response(JSON.stringify({ reply }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    console.error("abel-chat error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
