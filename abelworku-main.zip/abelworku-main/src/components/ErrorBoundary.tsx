import { Component, ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";

type State = { hasError: boolean; message: string };

export class ErrorBoundary extends Component<{ children: ReactNode }, State> {
  state: State = { hasError: false, message: "" };

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error.message };
  }

  componentDidCatch(error: Error, info: { componentStack?: string | null }) {
    supabase.from("error_logs").insert({
      page: typeof window !== "undefined" ? window.location.pathname : "",
      message: error.message,
      stack: (error.stack || "") + "\n" + (info.componentStack || ""),
      user_agent: typeof navigator !== "undefined" ? navigator.userAgent : "",
    }).then(() => {});
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="container mx-auto px-6 py-20 text-center">
          <h1 className="font-display text-3xl text-gradient-gold mb-2">Something went wrong</h1>
          <p className="text-muted-foreground mb-6">{this.state.message}</p>
          <button onClick={() => location.reload()} className="px-5 py-2 rounded-md gradient-gold text-primary-foreground">Reload</button>
        </div>
      );
    }
    return this.props.children;
  }
}
