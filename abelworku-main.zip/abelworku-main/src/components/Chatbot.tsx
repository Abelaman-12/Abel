import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MessageCircle, X, Send, Sparkles } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

type Msg = { role: "user" | "assistant"; content: string };

export function Chatbot() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([
    { role: "assistant", content: "Hi! I'm Abel's assistant. Ask me anything about Abel — his work, skills, or how to get in touch. ✨" },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const send = async () => {
    if (!input.trim() || loading) return;
    const userMsg: Msg = { role: "user", content: input.trim() };
    setMessages((p) => [...p, userMsg]);
    setInput("");
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("abel-chat", {
        body: { messages: [...messages, userMsg] },
      });
      if (error) throw error;
      setMessages((p) => [...p, { role: "assistant", content: data?.reply || "Sorry, I couldn't respond. Please try the contact page." }]);
    } catch {
      setMessages((p) => [...p, { role: "assistant", content: "I'm having trouble right now. For specific questions, please reach Abel directly: 0712278043 or 0944216043, or use the contact page." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <button
        onClick={() => setOpen(!open)}
        className="fixed bottom-6 right-6 z-50 h-14 w-14 rounded-full gradient-gold shadow-gold flex items-center justify-center text-primary-foreground hover:scale-110 transition-transform"
        aria-label="open chat"
      >
        {open ? <X className="h-5 w-5" /> : <MessageCircle className="h-5 w-5" />}
      </button>
      {open && (
        <div className="fixed bottom-24 right-6 z-50 w-[min(380px,calc(100vw-3rem))] h-[500px] rounded-2xl bg-card border border-border shadow-elegant flex flex-col overflow-hidden animate-scale-in">
          <div className="p-4 border-b border-border flex items-center gap-2 gradient-gold text-primary-foreground">
            <Sparkles className="h-4 w-4" />
            <div>
              <p className="font-display font-bold text-sm">Abel's AI Assistant</p>
              <p className="text-xs opacity-80">Ask me about Abel</p>
            </div>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <div className={`max-w-[85%] rounded-2xl px-4 py-2 text-sm ${
                  m.role === "user" ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground"
                }`}>{m.content}</div>
              </div>
            ))}
            {loading && <div className="text-xs text-muted-foreground">Thinking...</div>}
            <div ref={endRef} />
          </div>
          <div className="p-3 border-t border-border flex gap-2">
            <Input value={input} onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && send()}
              placeholder="Ask about Abel..." disabled={loading} />
            <Button size="icon" onClick={send} disabled={loading} className="gradient-gold">
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}
    </>
  );
}
