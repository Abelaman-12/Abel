import { Link, Outlet, useRouterState } from "@tanstack/react-router";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Menu, X, Sun, Moon, LogOut, Shield } from "lucide-react";
import { useState, useEffect } from "react";
import { Chatbot } from "@/components/Chatbot";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { supabase } from "@/integrations/supabase/client";

const navItems = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About" },
  { to: "/gallery", label: "Gallery" },
  { to: "/contact", label: "Contact" },
];

export function Layout() {
  const [open, setOpen] = useState(false);
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const { user, isAdmin, signOut } = useAuth();
  const path = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    const saved = (localStorage.getItem("theme") as "dark" | "light") || "dark";
    setTheme(saved);
    document.documentElement.classList.toggle("light", saved === "light");

    const onErr = (e: ErrorEvent) => {
      supabase.from("error_logs").insert({
        page: window.location.pathname,
        message: e.message,
        stack: e.error?.stack || "",
        user_agent: navigator.userAgent,
      }).then(() => {});
    };
    const onRej = (e: PromiseRejectionEvent) => {
      supabase.from("error_logs").insert({
        page: window.location.pathname,
        message: String(e.reason?.message || e.reason),
        stack: e.reason?.stack || "",
        user_agent: navigator.userAgent,
      }).then(() => {});
    };
    window.addEventListener("error", onErr);
    window.addEventListener("unhandledrejection", onRej);
    return () => { window.removeEventListener("error", onErr); window.removeEventListener("unhandledrejection", onRej); };
  }, []);

  const toggleTheme = () => {
    const next = theme === "dark" ? "light" : "dark";
    setTheme(next);
    localStorage.setItem("theme", next);
    document.documentElement.classList.toggle("light", next === "light");
  };

  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-50 glass border-b border-border/40">
        <div className="container mx-auto px-6 h-16 flex items-center justify-between">
          <Link to="/" className="font-display text-xl tracking-wider">
            <span className="text-gradient-gold font-bold">ABEL</span>
            <span className="text-muted-foreground"> WORKU</span>
          </Link>
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((n) => (
              <Link key={n.to} to={n.to}
                className={`px-4 py-2 rounded-md text-sm transition-colors ${path === n.to ? "text-gold" : "text-muted-foreground hover:text-foreground"}`}>
                {n.label}
              </Link>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" onClick={toggleTheme} aria-label="toggle theme">
              {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>
            {user ? (
              <>
                {isAdmin && (
                  <Link to="/vault-7f3e2k9">
                    <Button variant="outline" size="sm" className="border-gold/40 text-gold">
                      <Shield className="h-3.5 w-3.5 mr-1.5" /> Admin
                    </Button>
                  </Link>
                )}
                <Button variant="ghost" size="icon" onClick={signOut} aria-label="sign out">
                  <LogOut className="h-4 w-4" />
                </Button>
              </>
            ) : (
              <Link to="/auth"><Button size="sm" className="gradient-gold text-primary-foreground">Sign In</Button></Link>
            )}
            <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setOpen(!open)}>
              {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </Button>
          </div>
        </div>
        {open && (
          <div className="md:hidden border-t border-border/40">
            {navItems.map((n) => (
              <Link key={n.to} to={n.to} onClick={() => setOpen(false)}
                className="block px-6 py-3 hover:bg-secondary text-sm">
                {n.label}
              </Link>
            ))}
          </div>
        )}
      </header>

      <main className="flex-1"><ErrorBoundary><Outlet /></ErrorBoundary></main>

      <footer className="border-t border-border/40 py-8 mt-20">
        <div className="container mx-auto px-6 text-center text-sm text-muted-foreground">
          <p className="font-display text-gradient-gold text-lg mb-2">Abel Worku</p>
          <p>© {new Date().getFullYear()} — Forex Trader · Animator · Editor · Designer · Developer</p>
        </div>
      </footer>

      <Chatbot />
    </div>
  );
}
