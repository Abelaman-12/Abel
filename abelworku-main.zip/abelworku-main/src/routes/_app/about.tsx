import { createFileRoute, Link } from "@tanstack/react-router";
import { TrendingUp, Film, Video, Palette, Code, Award, Target, Heart } from "lucide-react";
import abelImg from "@/assets/abel-profile.jpg";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_app/about")({
  head: () => ({
    meta: [
      { title: "About Abel Worku — Multi-Disciplinary Creator" },
      { name: "description", content: "Learn about Abel Worku: forex trader, animator, editor, designer, developer with 1.5+ years of experience." },
    ],
  }),
  component: About,
});

const services = [
  { icon: TrendingUp, title: "Forex Trading", text: "Disciplined market analysis with risk-managed strategies. Trading the global currency markets with precision." },
  { icon: Film, title: "Stickman Animation", text: "Fluid stickman fight scenes and storytelling animations frame by frame, full of personality and impact." },
  { icon: Video, title: "Video Editing", text: "Cinematic cuts, color grading, motion graphics — turning raw footage into compelling stories." },
  { icon: Palette, title: "Graphic Design", text: "Logos, posters, thumbnails, brand identities — visuals that capture attention and convert." },
  { icon: Code, title: "Web Design", text: "Hand-coded HTML, CSS, and JavaScript websites that look incredible and run beautifully." },
];

function About() {
  return (
    <div className="container mx-auto px-6 py-16 md:py-24">
      <div className="max-w-3xl">
        <p className="text-sm uppercase tracking-[0.3em] text-gold mb-4">About Me</p>
        <h1 className="font-display text-5xl md:text-6xl font-bold mb-6">
          A creator who lives at the <span className="text-gradient-gold">intersection of art and discipline</span>
        </h1>
      </div>

      <div className="grid md:grid-cols-3 gap-12 mt-16 items-start">
        <div className="md:col-span-1">
          <div className="aspect-[4/5] rounded-2xl overflow-hidden shadow-elegant border border-gold/20">
            <img src={abelImg} alt="Abel Worku" className="w-full h-full object-cover" />
          </div>
        </div>
        <div className="md:col-span-2 space-y-6 text-muted-foreground leading-relaxed">
          <p className="text-lg text-foreground">
            I'm <span className="text-gold font-semibold">Abel Worku</span> — a multi-disciplinary creator who's spent the last <strong className="text-foreground">year and a half</strong> turning passion into craft.
          </p>
          <p>
            What started as curiosity became five interconnected pursuits: <strong className="text-foreground">forex trading</strong>, where I learned discipline and pattern recognition; <strong className="text-foreground">stickman animation</strong>, where every frame teaches patience; <strong className="text-foreground">video editing</strong>, where pacing tells the story; <strong className="text-foreground">graphic design</strong>, where shape and color shape emotion; and <strong className="text-foreground">web development</strong> with HTML, CSS, and JavaScript, where logic meets art.
          </p>
          <p>
            I believe the best creators are generalists with a specialist's depth. Every skill informs the others. Trading taught me to see signals in noise. Animation taught me time. Design taught me clarity. Code taught me structure. Together, they make me sharper at every single one.
          </p>
          <div className="grid grid-cols-3 gap-4 pt-4">
            {[{ i: Award, l: "Self-Taught" }, { i: Target, l: "Disciplined" }, { i: Heart, l: "Passionate" }].map((x) => (
              <div key={x.l} className="glass rounded-xl p-4 text-center">
                <x.i className="h-5 w-5 text-gold mx-auto mb-2" />
                <p className="text-xs">{x.l}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-24">
        <h2 className="font-display text-4xl mb-12 text-center">What I Do</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((s) => (
            <div key={s.title} className="glass rounded-2xl p-6 hover:border-gold/40 transition-colors">
              <s.icon className="h-8 w-8 text-gold mb-4" />
              <h3 className="font-display text-xl mb-2">{s.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{s.text}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-24 text-center glass rounded-3xl p-12">
        <h2 className="font-display text-3xl md:text-4xl mb-4">Let's create something extraordinary</h2>
        <p className="text-muted-foreground mb-6 max-w-xl mx-auto">Whether it's a project, a collaboration, or just a conversation — I'd love to hear from you.</p>
        <Link to="/contact"><Button size="lg" className="gradient-gold text-primary-foreground">Reach Out</Button></Link>
      </div>
    </div>
  );
}
