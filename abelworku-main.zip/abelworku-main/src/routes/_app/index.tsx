import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { TypingText } from "@/components/TypingText";
import { Button } from "@/components/ui/button";
import { ArrowRight, TrendingUp, Film, Video, Palette, Code, Award, ExternalLink } from "lucide-react";
import abelImg from "@/assets/abel-profile.jpg";

export const Route = createFileRoute("/_app/")({
  component: Home,
});

const skills = [
  { icon: TrendingUp, label: "Forex Trader" },
  { icon: Film, label: "Stickman Animator" },
  { icon: Video, label: "Video Editor" },
  { icon: Palette, label: "Graphic Designer" },
  { icon: Code, label: "Web Developer" },
];

type Settings = { hero_name: string; tagline: string; bio: string | null; profile_image_url: string | null; experience_text: string; stat_disciplines: string; stat_projects: string; stat_ideas: string };
type Cert = { id: string; title: string; issuer: string | null; year: string | null; image_url: string; link: string | null };

function Home() {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [certs, setCerts] = useState<Cert[]>([]);
  const [projectCount, setProjectCount] = useState<number>(0);

  useEffect(() => {
    const load = async () => {
      const [s, c, g] = await Promise.all([
        supabase.from("portfolio_settings").select("*").eq("id", 1).maybeSingle(),
        supabase.from("certificates").select("*").order("created_at", { ascending: false }),
        supabase.from("gallery_items").select("id", { count: "exact", head: true }),
      ]);
      if (s.data) setSettings(s.data as Settings);
      setCerts((c.data || []) as Cert[]);
      setProjectCount(g.count || 0);
    };
    load();
    const ch = supabase.channel("home")
      .on("postgres_changes", { event: "*", schema: "public", table: "gallery_items" }, load)
      .on("postgres_changes", { event: "*", schema: "public", table: "certificates" }, load)
      .on("postgres_changes", { event: "*", schema: "public", table: "portfolio_settings" }, load)
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, []);

  const heroName = settings?.hero_name || "Abel Worku";
  const tagline = settings?.tagline || "Crafting precision in the markets and creativity on screen.";
  const profileSrc = settings?.profile_image_url || abelImg;
  const exp = settings?.experience_text || "1.5+ Years";
  const projectsLabel = projectCount > 0 ? `${projectCount}+` : (settings?.stat_projects || "100+");

  return (
    <>
      <section className="relative hero-bg overflow-hidden">
        <div className="container mx-auto px-6 py-20 md:py-32 grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6 animate-fade-in">
            <p className="text-sm uppercase tracking-[0.3em] text-gold">Portfolio</p>
            <h1 className="font-display text-5xl md:text-7xl font-bold leading-[1.05]">
              Hi, I'm <span className="text-gradient-gold">{heroName}</span>
            </h1>
            <div className="text-2xl md:text-3xl font-display text-muted-foreground min-h-[3rem]">
              I'm a <TypingText
                phrases={["Forex Trader.", "Stickman Animator.", "Video Editor.", "Graphic Designer.", "Web Developer."]}
                className="text-gold" />
            </div>
            <p className="text-base md:text-lg text-muted-foreground max-w-xl leading-relaxed">{tagline}</p>
            <div className="flex flex-wrap gap-3 pt-4">
              <Link to="/gallery"><Button size="lg" className="gradient-gold text-primary-foreground shadow-gold">View My Work <ArrowRight className="ml-2 h-4 w-4" /></Button></Link>
              <Link to="/contact"><Button size="lg" variant="outline" className="border-gold/50 text-gold hover:bg-gold/10">Get In Touch</Button></Link>
            </div>
            <div className="flex flex-wrap gap-2 pt-6">
              {skills.map((s) => (
                <div key={s.label} className="flex items-center gap-2 px-3 py-1.5 rounded-full glass text-xs">
                  <s.icon className="h-3.5 w-3.5 text-gold" /><span>{s.label}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="relative animate-float">
            <div className="absolute inset-0 gradient-gold blur-3xl opacity-30 rounded-full" />
            <div className="relative aspect-square max-w-md mx-auto rounded-full overflow-hidden border-4 border-gold/30 shadow-gold">
              <img src={profileSrc} alt={heroName} className="w-full h-full object-cover" />
            </div>
            <div className="absolute -bottom-4 -right-4 glass rounded-2xl px-5 py-3">
              <p className="text-xs text-muted-foreground">Experience</p>
              <p className="font-display text-2xl text-gradient-gold font-bold">{exp}</p>
            </div>
          </div>
        </div>
      </section>

      <section className="container mx-auto px-6 py-20">
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { n: settings?.stat_disciplines || "5", l: "Disciplines mastered" },
            { n: projectsLabel, l: "Projects delivered" },
            { n: settings?.stat_ideas || "∞", l: "Ideas in motion" },
          ].map((s) => (
            <div key={s.l} className="glass rounded-2xl p-8 text-center">
              <p className="font-display text-5xl text-gradient-gold font-bold">{s.n}</p>
              <p className="mt-2 text-sm text-muted-foreground uppercase tracking-wider">{s.l}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="container mx-auto px-6 py-12 md:py-20">
        <div className="text-center mb-10">
          <p className="text-xs uppercase tracking-[0.3em] text-gold mb-3">Credentials</p>
          <h2 className="font-display text-4xl md:text-5xl font-bold">My <span className="text-gradient-gold">Certificates</span></h2>
          <p className="mt-3 text-muted-foreground">Verified achievements and recognitions.</p>
        </div>
        {certs.length === 0 ? (
          <div className="glass rounded-2xl p-10 text-center text-muted-foreground">
            <Award className="h-10 w-10 mx-auto text-gold mb-3" />
            <p>Certificates coming soon.</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {certs.map((c) => (
              <div key={c.id} className="glass rounded-2xl overflow-hidden group hover:border-gold/40 transition-colors">
                <img src={c.image_url} alt={c.title} className="w-full aspect-video object-cover group-hover:scale-105 transition-transform duration-500" />
                <div className="p-5">
                  <p className="font-display text-lg">{c.title}</p>
                  <p className="text-xs text-muted-foreground mt-1">{c.issuer}{c.year && ` · ${c.year}`}</p>
                  {c.link && <a href={c.link} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 mt-3 text-xs text-gold hover:underline">Verify <ExternalLink className="h-3 w-3" /></a>}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </>
  );
}
