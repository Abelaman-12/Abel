import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Phone, Mail, Send, MessageCircle, Paperclip, X } from "lucide-react";

export const Route = createFileRoute("/_app/contact")({
  head: () => ({
    meta: [
      { title: "Contact Abel Worku" },
      { name: "description", content: "Get in touch with Abel Worku — phone, email, Telegram, YouTube, TikTok." },
    ],
  }),
  component: Contact,
});

const schema = z.object({
  name: z.string().trim().min(1).max(100),
  email: z.string().trim().email().max(255),
  message: z.string().trim().min(5).max(2000),
});

const channels = [
  { icon: Phone, label: "Phone", value: "0712278043", href: "tel:0712278043" },
  { icon: Phone, label: "Phone", value: "0944216043", href: "tel:0944216043" },
  { icon: Mail, label: "Email", value: "abelw@gmail.com", href: "mailto:abelw@gmail.com" },
  { icon: MessageCircle, label: "Telegram", value: "@mymoney2024", href: "https://t.me/mymoney2024" },
  { icon: Send, label: "YouTube", value: "@TOM_YouTuber98", href: "https://youtube.com/@TOM_YouTuber98" },
  { icon: Send, label: "TikTok", value: "@tom_forextrader98", href: "https://tiktok.com/@tom_forextrader98" },
];

function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse(form);
    if (!parsed.success) return toast.error(parsed.error.issues[0].message);
    setLoading(true);
    try {
      let attachment_url: string | null = null;
      if (file) {
        if (file.size > 10 * 1024 * 1024) throw new Error("File too large (max 10MB)");
        const path = `anon/${Date.now()}-${file.name}`;
        const { error: e1 } = await supabase.storage.from("message-attachments").upload(path, file);
        if (e1) throw e1;
        attachment_url = supabase.storage.from("message-attachments").getPublicUrl(path).data.publicUrl;
      }
      let location: string | null = null;
      try {
        const r = await fetch("https://ipapi.co/json/");
        const j = await r.json();
        location = [j.city, j.country_name].filter(Boolean).join(", ") || null;
      } catch {}
      const { error } = await supabase.from("contact_messages").insert({ ...parsed.data, attachment_url, location });
      if (error) throw error;
      toast.success("Message sent! Abel will reply soon.");
      setForm({ name: "", email: "", message: "" });
      setFile(null);
    } catch (err: any) {
      toast.error(err.message || "Failed to send.");
    } finally { setLoading(false); }
  };

  return (
    <div className="container mx-auto px-6 py-16 md:py-24">
      <div className="text-center mb-12">
        <p className="text-sm uppercase tracking-[0.3em] text-gold mb-4">Contact</p>
        <h1 className="font-display text-5xl md:text-6xl font-bold">Let's <span className="text-gradient-gold">Talk</span></h1>
        <p className="mt-4 text-muted-foreground max-w-xl mx-auto">Reach out via any channel — I respond within 24 hours.</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8 max-w-5xl mx-auto">
        <div className="space-y-3">
          <h2 className="font-display text-2xl mb-4">Direct channels</h2>
          {channels.map((c, i) => (
            <a key={i} href={c.href} target={c.href.startsWith("http") ? "_blank" : undefined} rel="noopener noreferrer"
              className="flex items-center gap-4 glass rounded-xl p-4 hover:border-gold/40 transition-colors group">
              <div className="h-10 w-10 rounded-full gradient-gold flex items-center justify-center text-primary-foreground"><c.icon className="h-4 w-4" /></div>
              <div className="flex-1">
                <p className="text-xs text-muted-foreground uppercase tracking-wider">{c.label}</p>
                <p className="font-medium group-hover:text-gold transition-colors">{c.value}</p>
              </div>
            </a>
          ))}
        </div>

        <form onSubmit={submit} className="glass rounded-2xl p-6 space-y-4">
          <h2 className="font-display text-2xl mb-2">Send a message</h2>
          <div><Label htmlFor="name">Name</Label><Input id="name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required maxLength={100} /></div>
          <div><Label htmlFor="email">Email</Label><Input id="email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required maxLength={255} /></div>
          <div><Label htmlFor="message">Message</Label><Textarea id="message" rows={5} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} required maxLength={2000} /></div>
          <div>
            <Label htmlFor="attach" className="flex items-center gap-2 cursor-pointer text-sm text-muted-foreground hover:text-gold">
              <Paperclip className="h-4 w-4" /> {file ? file.name : "Attach an image (optional)"}
            </Label>
            <Input id="attach" type="file" accept="image/*" className="hidden" onChange={(e) => setFile(e.target.files?.[0] || null)} />
            {file && <Button type="button" variant="ghost" size="sm" onClick={() => setFile(null)}><X className="h-3 w-3 mr-1" />Remove</Button>}
          </div>
          <Button type="submit" disabled={loading} className="w-full gradient-gold text-primary-foreground">{loading ? "Sending..." : "Send Message"}</Button>
        </form>
      </div>
    </div>
  );
}
