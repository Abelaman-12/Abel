import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Trash2, Eye, Mail, Upload, Award, Newspaper, Settings as SettingsIcon, Bug, Check } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, CartesianGrid } from "recharts";

export const Route = createFileRoute("/_app/vault-7f3e2k9")({
  component: Admin,
});

type GalleryItem = { id: string; title: string; description: string | null; category: string; image_url: string; video_url: string | null; media_type: string; view_count: number; created_at: string };
type Message = { id: string; name: string; email: string; message: string; is_read: boolean; reply: string | null; attachment_url: string | null; location: string | null; created_at: string };
type View = { item_id: string; viewer_age: number | null; viewed_at: string };
type Cert = { id: string; title: string; issuer: string | null; year: string | null; image_url: string; link: string | null };
type News = { id: string; title: string; content: string | null; media_url: string | null; media_type: string | null; created_at: string };
type ErrorLog = { id: string; page: string | null; message: string; stack: string | null; resolved: boolean; resolution_note: string | null; created_at: string };
type Settings = { id: number; hero_name: string; tagline: string; bio: string | null; profile_image_url: string | null; experience_text: string; stat_disciplines: string; stat_projects: string; stat_ideas: string };

async function uploadToBucket(bucket: string, file: File, userId: string) {
  const ext = file.name.split(".").pop();
  const path = `${userId}/${Date.now()}.${ext}`;
  const { error } = await supabase.storage.from(bucket).upload(path, file);
  if (error) throw error;
  return supabase.storage.from(bucket).getPublicUrl(path).data.publicUrl;
}

function Admin() {
  const { user, isAdmin, loading } = useAuth();
  const navigate = useNavigate();
  const [items, setItems] = useState<GalleryItem[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [views, setViews] = useState<View[]>([]);
  const [certs, setCerts] = useState<Cert[]>([]);
  const [news, setNews] = useState<News[]>([]);
  const [errors, setErrors] = useState<ErrorLog[]>([]);
  const [settings, setSettings] = useState<Settings | null>(null);
  const [minAge, setMinAge] = useState(0);
  const [maxAge, setMaxAge] = useState(100);

  const [post, setPost] = useState({ title: "", description: "", category: "design", media_type: "image" as "image" | "video", file: null as File | null });
  const [uploading, setUploading] = useState(false);
  const [cert, setCert] = useState({ title: "", issuer: "", year: "", link: "", file: null as File | null });
  const [newsForm, setNewsForm] = useState({ title: "", content: "", media_type: "image" as "image" | "video", file: null as File | null });

  useEffect(() => {
    if (!loading && (!user || !isAdmin)) navigate({ to: "/" });
  }, [user, isAdmin, loading, navigate]);

  const loadAll = async () => {
    const [g, m, v, c, n, e, s] = await Promise.all([
      supabase.from("gallery_items").select("*").order("created_at", { ascending: false }),
      supabase.from("contact_messages").select("*").order("created_at", { ascending: false }),
      supabase.from("gallery_views").select("item_id, viewer_age, viewed_at").order("viewed_at", { ascending: false }).limit(500),
      supabase.from("certificates").select("*").order("created_at", { ascending: false }),
      supabase.from("news_posts").select("*").order("created_at", { ascending: false }),
      supabase.from("error_logs").select("*").order("created_at", { ascending: false }).limit(200),
      supabase.from("portfolio_settings").select("*").eq("id", 1).maybeSingle(),
    ]);
    setItems((g.data || []) as GalleryItem[]);
    setMessages((m.data || []) as Message[]);
    setViews((v.data || []) as View[]);
    setCerts((c.data || []) as Cert[]);
    setNews((n.data || []) as News[]);
    setErrors((e.data || []) as ErrorLog[]);
    setSettings((s.data || null) as Settings | null);
  };

  useEffect(() => {
    if (isAdmin) {
      loadAll();
      const ch = supabase.channel("admin-all")
        .on("postgres_changes", { event: "*", schema: "public" }, loadAll).subscribe();
      return () => { supabase.removeChannel(ch); };
    }
  }, [isAdmin]);

  if (loading || !isAdmin) return <div className="container mx-auto px-6 py-20 text-center text-muted-foreground">Loading…</div>;

  const upload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!post.file) return toast.error("Choose a file");
    setUploading(true);
    try {
      const bucket = post.media_type === "video" ? "media" : "gallery";
      const url = await uploadToBucket(bucket, post.file, user!.id);
      const { error } = await supabase.from("gallery_items").insert({
        title: post.title, description: post.description, category: post.category,
        image_url: post.media_type === "image" ? url : (settings?.profile_image_url || url),
        video_url: post.media_type === "video" ? url : null,
        media_type: post.media_type,
        created_by: user!.id,
      });
      if (error) throw error;
      toast.success("Posted!");
      setPost({ title: "", description: "", category: "design", media_type: "image", file: null });
    } catch (err: any) { toast.error(err.message || "Upload failed"); }
    finally { setUploading(false); }
  };

  const submitCert = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!cert.file) return toast.error("Choose an image");
    setUploading(true);
    try {
      const url = await uploadToBucket("gallery", cert.file, user!.id);
      const { error } = await supabase.from("certificates").insert({
        title: cert.title, issuer: cert.issuer, year: cert.year, link: cert.link, image_url: url, created_by: user!.id,
      });
      if (error) throw error;
      toast.success("Certificate added!");
      setCert({ title: "", issuer: "", year: "", link: "", file: null });
    } catch (err: any) { toast.error(err.message); }
    finally { setUploading(false); }
  };

  const submitNews = async (e: React.FormEvent) => {
    e.preventDefault();
    setUploading(true);
    try {
      let media_url: string | null = null;
      if (newsForm.file) {
        const bucket = newsForm.media_type === "video" ? "media" : "gallery";
        media_url = await uploadToBucket(bucket, newsForm.file, user!.id);
      }
      const { error } = await supabase.from("news_posts").insert({
        title: newsForm.title, content: newsForm.content, media_url, media_type: newsForm.media_type, created_by: user!.id,
      });
      if (error) throw error;
      toast.success("News posted!");
      setNewsForm({ title: "", content: "", media_type: "image", file: null });
    } catch (err: any) { toast.error(err.message); }
    finally { setUploading(false); }
  };

  const saveSettings = async () => {
    if (!settings) return;
    const { error } = await supabase.from("portfolio_settings").update({
      hero_name: settings.hero_name, tagline: settings.tagline, bio: settings.bio,
      profile_image_url: settings.profile_image_url, experience_text: settings.experience_text,
      stat_disciplines: settings.stat_disciplines, stat_projects: settings.stat_projects, stat_ideas: settings.stat_ideas,
      updated_at: new Date().toISOString(),
    }).eq("id", 1);
    if (error) toast.error(error.message); else toast.success("Profile updated");
  };

  const uploadProfile = async (file: File) => {
    const url = await uploadToBucket("gallery", file, user!.id);
    setSettings((s) => s ? { ...s, profile_image_url: url } : s);
    await supabase.from("portfolio_settings").update({ profile_image_url: url }).eq("id", 1);
    toast.success("Profile image updated");
  };

  const filteredViews = views.filter((v) => {
    const a = v.viewer_age;
    if (a === null) return minAge === 0;
    return a >= minAge && a <= maxAge;
  });
  const viewsByDay: Record<string, number> = {};
  filteredViews.forEach((v) => {
    const d = new Date(v.viewed_at).toLocaleDateString();
    viewsByDay[d] = (viewsByDay[d] || 0) + 1;
  });
  const chartData = Object.entries(viewsByDay).slice(-14).map(([date, count]) => ({ date, count }));
  const ageBuckets = [{ label: "<14", min: 0, max: 13 }, { label: "14-18", min: 14, max: 18 }, { label: "19-25", min: 19, max: 25 }, { label: "26-35", min: 26, max: 35 }, { label: "36+", min: 36, max: 200 }];
  const ageData = ageBuckets.map((b) => ({ age: b.label, count: views.filter((v) => v.viewer_age !== null && v.viewer_age! >= b.min && v.viewer_age! <= b.max).length }));
  const unread = messages.filter((m) => !m.is_read).length;
  const unresolved = errors.filter((e) => !e.resolved).length;

  return (
    <div className="container mx-auto px-6 py-12">
      <div className="flex items-center justify-between mb-8 flex-wrap gap-4">
        <div>
          <p className="text-xs uppercase tracking-[0.3em] text-gold">Admin Vault</p>
          <h1 className="font-display text-4xl">Dashboard</h1>
        </div>
        <div className="flex gap-3 flex-wrap">
          <div className="glass rounded-xl px-4 py-2 text-center"><p className="text-xs text-muted-foreground">Posts</p><p className="font-display text-xl text-gold">{items.length}</p></div>
          <div className="glass rounded-xl px-4 py-2 text-center"><p className="text-xs text-muted-foreground">Views</p><p className="font-display text-xl text-gold">{views.length}</p></div>
          <div className="glass rounded-xl px-4 py-2 text-center"><p className="text-xs text-muted-foreground">Unread</p><p className="font-display text-xl text-gold">{unread}</p></div>
          <div className="glass rounded-xl px-4 py-2 text-center"><p className="text-xs text-muted-foreground">Errors</p><p className="font-display text-xl text-destructive">{unresolved}</p></div>
        </div>
      </div>

      <Tabs defaultValue="post">
        <TabsList className="flex-wrap h-auto">
          <TabsTrigger value="post"><Upload className="h-4 w-4 mr-1" />Gallery</TabsTrigger>
          <TabsTrigger value="cert"><Award className="h-4 w-4 mr-1" />Certificates</TabsTrigger>
          <TabsTrigger value="news"><Newspaper className="h-4 w-4 mr-1" />News</TabsTrigger>
          <TabsTrigger value="messages"><Mail className="h-4 w-4 mr-1" />Messages ({unread})</TabsTrigger>
          <TabsTrigger value="profile"><SettingsIcon className="h-4 w-4 mr-1" />Profile</TabsTrigger>
          <TabsTrigger value="errors"><Bug className="h-4 w-4 mr-1" />Errors ({unresolved})</TabsTrigger>
          <TabsTrigger value="analytics"><Eye className="h-4 w-4 mr-1" />Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="post" className="pt-6 space-y-6">
          <form onSubmit={upload} className="glass rounded-2xl p-6 space-y-4 max-w-xl">
            <h2 className="font-display text-2xl">Post to gallery</h2>
            <div><Label>Title</Label><Input required value={post.title} onChange={(e) => setPost({ ...post, title: e.target.value })} /></div>
            <div><Label>Description</Label><Textarea value={post.description} onChange={(e) => setPost({ ...post, description: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Type</Label>
                <Select value={post.media_type} onValueChange={(v: "image" | "video") => setPost({ ...post, media_type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="image">Image</SelectItem><SelectItem value="video">Video</SelectItem></SelectContent>
                </Select>
              </div>
              <div>
                <Label>Category</Label>
                <Select value={post.category} onValueChange={(v) => setPost({ ...post, category: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{["forex","animation","video","design","web","other"].map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div><Label>File ({post.media_type})</Label><Input type="file" accept={post.media_type === "video" ? "video/*" : "image/*"} required onChange={(e) => setPost({ ...post, file: e.target.files?.[0] || null })} /></div>
            <Button disabled={uploading} className="gradient-gold text-primary-foreground">{uploading ? "Uploading..." : "Post"}</Button>
          </form>

          <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {items.map((it) => (
              <div key={it.id} className="glass rounded-xl overflow-hidden">
                {it.media_type === "video" && it.video_url ? (
                  <video src={it.video_url} className="w-full aspect-square object-cover" muted />
                ) : (
                  <img src={it.image_url} className="w-full aspect-square object-cover" alt={it.title} />
                )}
                <div className="p-3">
                  <p className="font-medium text-sm truncate">{it.title}</p>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-xs text-muted-foreground flex items-center gap-1"><Eye className="h-3 w-3" />{it.view_count}</span>
                    <Button size="sm" variant="ghost" onClick={async () => { if (confirm("Delete?")) { await supabase.from("gallery_items").delete().eq("id", it.id); toast.success("Deleted"); } }}><Trash2 className="h-3 w-3 text-destructive" /></Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="cert" className="pt-6 space-y-6">
          <form onSubmit={submitCert} className="glass rounded-2xl p-6 space-y-4 max-w-xl">
            <h2 className="font-display text-2xl">Add certificate</h2>
            <div><Label>Title</Label><Input required value={cert.title} onChange={(e) => setCert({ ...cert, title: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Issuer</Label><Input value={cert.issuer} onChange={(e) => setCert({ ...cert, issuer: e.target.value })} /></div>
              <div><Label>Year</Label><Input value={cert.year} onChange={(e) => setCert({ ...cert, year: e.target.value })} /></div>
            </div>
            <div><Label>Verify link (optional)</Label><Input value={cert.link} onChange={(e) => setCert({ ...cert, link: e.target.value })} /></div>
            <div><Label>Certificate image</Label><Input type="file" accept="image/*" required onChange={(e) => setCert({ ...cert, file: e.target.files?.[0] || null })} /></div>
            <Button disabled={uploading} className="gradient-gold text-primary-foreground">{uploading ? "Uploading..." : "Add"}</Button>
          </form>
          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
            {certs.map((c) => (
              <div key={c.id} className="glass rounded-xl overflow-hidden">
                <img src={c.image_url} className="w-full aspect-video object-cover" alt={c.title} />
                <div className="p-3">
                  <p className="font-medium">{c.title}</p>
                  <p className="text-xs text-muted-foreground">{c.issuer} · {c.year}</p>
                  <Button size="sm" variant="ghost" onClick={async () => { if (confirm("Delete?")) { await supabase.from("certificates").delete().eq("id", c.id); toast.success("Deleted"); } }}><Trash2 className="h-3 w-3 text-destructive" /></Button>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="news" className="pt-6 space-y-6">
          <form onSubmit={submitNews} className="glass rounded-2xl p-6 space-y-4 max-w-xl">
            <h2 className="font-display text-2xl">Post news / idea</h2>
            <div><Label>Title</Label><Input required value={newsForm.title} onChange={(e) => setNewsForm({ ...newsForm, title: e.target.value })} /></div>
            <div><Label>Content</Label><Textarea rows={4} value={newsForm.content} onChange={(e) => setNewsForm({ ...newsForm, content: e.target.value })} /></div>
            <div>
              <Label>Media type</Label>
              <Select value={newsForm.media_type} onValueChange={(v: "image"|"video") => setNewsForm({ ...newsForm, media_type: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="image">Image</SelectItem><SelectItem value="video">Video</SelectItem></SelectContent>
              </Select>
            </div>
            <div><Label>File (optional)</Label><Input type="file" accept={newsForm.media_type === "video" ? "video/*" : "image/*"} onChange={(e) => setNewsForm({ ...newsForm, file: e.target.files?.[0] || null })} /></div>
            <Button disabled={uploading} className="gradient-gold text-primary-foreground">{uploading ? "Posting..." : "Publish"}</Button>
          </form>
          <div className="space-y-3">
            {news.map((n) => (
              <div key={n.id} className="glass rounded-xl p-4">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <p className="font-display text-lg">{n.title}</p>
                    <p className="text-xs text-muted-foreground">{new Date(n.created_at).toLocaleString()}</p>
                    {n.content && <p className="text-sm mt-2">{n.content}</p>}
                  </div>
                  <Button size="sm" variant="ghost" onClick={async () => { if (confirm("Delete?")) { await supabase.from("news_posts").delete().eq("id", n.id); toast.success("Deleted"); } }}><Trash2 className="h-3 w-3 text-destructive" /></Button>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="messages" className="pt-6 space-y-3">
          {messages.length === 0 ? <p className="text-muted-foreground">No messages yet.</p> :
            messages.map((m) => <MessageRow key={m.id} m={m} onReply={async (id, reply) => { await supabase.from("contact_messages").update({ reply, is_read: true }).eq("id", id); toast.success("Saved"); }} />)}
        </TabsContent>

        <TabsContent value="profile" className="pt-6">
          {settings && (
            <div className="glass rounded-2xl p-6 space-y-4 max-w-2xl">
              <h2 className="font-display text-2xl">Edit portfolio profile</h2>
              <div className="flex gap-4 items-center">
                {settings.profile_image_url && <img src={settings.profile_image_url} className="w-24 h-24 rounded-full object-cover border-2 border-gold/40" alt="profile" />}
                <Input type="file" accept="image/*" onChange={(e) => e.target.files?.[0] && uploadProfile(e.target.files[0])} />
              </div>
              <div><Label>Name</Label><Input value={settings.hero_name} onChange={(e) => setSettings({ ...settings, hero_name: e.target.value })} /></div>
              <div><Label>Tagline</Label><Input value={settings.tagline} onChange={(e) => setSettings({ ...settings, tagline: e.target.value })} /></div>
              <div><Label>Bio</Label><Textarea value={settings.bio || ""} onChange={(e) => setSettings({ ...settings, bio: e.target.value })} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Experience</Label><Input value={settings.experience_text} onChange={(e) => setSettings({ ...settings, experience_text: e.target.value })} /></div>
                <div><Label>Disciplines</Label><Input value={settings.stat_disciplines} onChange={(e) => setSettings({ ...settings, stat_disciplines: e.target.value })} /></div>
                <div><Label>Projects</Label><Input value={settings.stat_projects} onChange={(e) => setSettings({ ...settings, stat_projects: e.target.value })} /></div>
                <div><Label>Ideas</Label><Input value={settings.stat_ideas} onChange={(e) => setSettings({ ...settings, stat_ideas: e.target.value })} /></div>
              </div>
              <Button onClick={saveSettings} className="gradient-gold text-primary-foreground">Save</Button>
            </div>
          )}
        </TabsContent>

        <TabsContent value="errors" className="pt-6 space-y-3">
          {errors.length === 0 ? <p className="text-muted-foreground">No errors logged.</p> : errors.map((e) => (
            <div key={e.id} className={`glass rounded-xl p-4 ${e.resolved ? "opacity-60" : "border-destructive/40"}`}>
              <div className="flex justify-between items-start gap-4">
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm break-words">{e.message}</p>
                  <p className="text-xs text-muted-foreground">{e.page} · {new Date(e.created_at).toLocaleString()}</p>
                  {e.stack && <pre className="text-xs mt-2 p-2 bg-background/50 rounded overflow-auto max-h-32">{e.stack}</pre>}
                </div>
                <div className="flex gap-2">
                  {!e.resolved && <Button size="sm" variant="outline" onClick={async () => { await supabase.from("error_logs").update({ resolved: true, resolution_note: "Fixed by admin" }).eq("id", e.id); toast.success("Marked resolved"); }}><Check className="h-3 w-3" /></Button>}
                  <Button size="sm" variant="ghost" onClick={async () => { await supabase.from("error_logs").delete().eq("id", e.id); }}><Trash2 className="h-3 w-3 text-destructive" /></Button>
                </div>
              </div>
            </div>
          ))}
        </TabsContent>

        <TabsContent value="analytics" className="pt-6 space-y-6">
          <div className="glass rounded-2xl p-6">
            <h3 className="font-display text-xl mb-4">Filter views by age</h3>
            <div className="flex gap-4 mb-4">
              <div><Label>Min</Label><Input type="number" value={minAge} onChange={(e) => setMinAge(+e.target.value)} className="w-24" /></div>
              <div><Label>Max</Label><Input type="number" value={maxAge} onChange={(e) => setMaxAge(+e.target.value)} className="w-24" /></div>
              <div className="flex items-end"><p className="text-sm text-muted-foreground">{filteredViews.length} views</p></div>
            </div>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.3 0 0)" />
                <XAxis dataKey="date" stroke="oklch(0.7 0 0)" fontSize={11} />
                <YAxis stroke="oklch(0.7 0 0)" fontSize={11} />
                <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)" }} />
                <Line type="monotone" dataKey="count" stroke="var(--gold)" strokeWidth={2} dot={{ fill: "var(--gold)" }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="glass rounded-2xl p-6">
            <h3 className="font-display text-xl mb-4">Views by age group</h3>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={ageData}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.3 0 0)" />
                <XAxis dataKey="age" stroke="oklch(0.7 0 0)" fontSize={11} />
                <YAxis stroke="oklch(0.7 0 0)" fontSize={11} />
                <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)" }} />
                <Bar dataKey="count" fill="var(--gold)" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function MessageRow({ m, onReply }: { m: Message; onReply: (id: string, reply: string) => void }) {
  const [reply, setReply] = useState(m.reply || "");
  return (
    <div className={`glass rounded-xl p-4 ${m.is_read ? "" : "border-gold/40"}`}>
      <div className="flex items-start justify-between mb-2">
        <div>
          <p className="font-medium">{m.name} <span className="text-muted-foreground text-xs">· {m.email}</span></p>
          <p className="text-xs text-muted-foreground">{new Date(m.created_at).toLocaleString()}{m.location && ` · ${m.location}`}</p>
        </div>
        {!m.is_read && <span className="text-xs px-2 py-1 rounded-full gradient-gold text-primary-foreground">NEW</span>}
      </div>
      <p className="text-sm mb-3 whitespace-pre-wrap">{m.message}</p>
      {m.attachment_url && <a href={m.attachment_url} target="_blank" rel="noopener noreferrer"><img src={m.attachment_url} alt="attachment" className="max-h-48 rounded-lg mb-3 border border-border" /></a>}
      <Textarea placeholder="Reply..." value={reply} onChange={(e) => setReply(e.target.value)} rows={2} />
      <Button size="sm" className="mt-2 gradient-gold text-primary-foreground" onClick={() => onReply(m.id, reply)}>Save Reply</Button>
    </div>
  );
}
