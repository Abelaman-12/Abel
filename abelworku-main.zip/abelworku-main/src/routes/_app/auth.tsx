import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";

export const Route = createFileRoute("/_app/auth")({
  component: Auth,
});

function Auth() {
  const navigate = useNavigate();
  const { user, loading } = useAuth();
  const [signin, setSignin] = useState({ email: "", password: "" });
  const [signup, setSignup] = useState({
    email: "", password: "", full_name: "", age: "", referral_source: "", country: "",
  });
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!loading && user) navigate({ to: "/" });
  }, [user, loading, navigate]);

  const doSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword(signin);
    setBusy(false);
    if (error) toast.error(error.message);
    else { toast.success("Welcome back!"); navigate({ to: "/" }); }
  };

  const doSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (signup.password.length < 8) return toast.error("Password must be at least 8 characters");
    setBusy(true);
    const { error } = await supabase.auth.signUp({
      email: signup.email,
      password: signup.password,
      options: {
        emailRedirectTo: `${window.location.origin}/`,
        data: {
          full_name: signup.full_name,
          age: signup.age,
          referral_source: signup.referral_source,
          country: signup.country,
        },
      },
    });
    setBusy(false);
    if (error) toast.error(error.message);
    else { toast.success("Account created!"); navigate({ to: "/" }); }
  };

  const doGoogle = async () => {
    setBusy(true);
    const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
    if (r.error) { toast.error("Google sign-in failed"); setBusy(false); }
  };

  return (
    <div className="container mx-auto px-6 py-16 max-w-md">
      <Link to="/" className="text-sm text-muted-foreground hover:text-gold">← Back home</Link>
      <div className="glass rounded-2xl p-8 mt-6">
        <h1 className="font-display text-3xl text-center mb-2 text-gradient-gold">Welcome</h1>
        <p className="text-center text-sm text-muted-foreground mb-6">Sign in to continue</p>

        <Button onClick={doGoogle} disabled={busy} variant="outline" className="w-full mb-4">
          Continue with Google
        </Button>
        <div className="flex items-center gap-2 mb-4 text-xs text-muted-foreground">
          <div className="flex-1 h-px bg-border" /> OR <div className="flex-1 h-px bg-border" />
        </div>

        <Tabs defaultValue="signin">
          <TabsList className="grid grid-cols-2 w-full">
            <TabsTrigger value="signin">Sign In</TabsTrigger>
            <TabsTrigger value="signup">Sign Up</TabsTrigger>
          </TabsList>

          <TabsContent value="signin" className="space-y-3 pt-4">
            <form onSubmit={doSignIn} className="space-y-3">
              <div><Label>Email</Label><Input type="email" required value={signin.email} onChange={(e) => setSignin({ ...signin, email: e.target.value })} /></div>
              <div><Label>Password</Label><Input type="password" required value={signin.password} onChange={(e) => setSignin({ ...signin, password: e.target.value })} /></div>
              <Button disabled={busy} className="w-full gradient-gold text-primary-foreground">Sign In</Button>
            </form>
          </TabsContent>

          <TabsContent value="signup" className="space-y-3 pt-4">
            <form onSubmit={doSignUp} className="space-y-3">
              <div><Label>Full name</Label><Input required value={signup.full_name} onChange={(e) => setSignup({ ...signup, full_name: e.target.value })} /></div>
              <div><Label>Email</Label><Input type="email" required value={signup.email} onChange={(e) => setSignup({ ...signup, email: e.target.value })} /></div>
              <div><Label>Password (min 8 chars)</Label><Input type="password" required minLength={8} value={signup.password} onChange={(e) => setSignup({ ...signup, password: e.target.value })} /></div>
              <div><Label>Age</Label><Input type="number" min={1} max={120} value={signup.age} onChange={(e) => setSignup({ ...signup, age: e.target.value })} /></div>
              <div><Label>Where are you from? (Country / City)</Label><Input placeholder="e.g. Addis Ababa, Ethiopia" value={signup.country} onChange={(e) => setSignup({ ...signup, country: e.target.value })} /></div>
              <div>
                <Label>How did you hear about us?</Label>
                <Select value={signup.referral_source} onValueChange={(v) => setSignup({ ...signup, referral_source: v })}>
                  <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="tiktok">TikTok</SelectItem>
                    <SelectItem value="telegram">Telegram</SelectItem>
                    <SelectItem value="youtube">YouTube</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button disabled={busy} className="w-full gradient-gold text-primary-foreground">Create Account</Button>
            </form>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
