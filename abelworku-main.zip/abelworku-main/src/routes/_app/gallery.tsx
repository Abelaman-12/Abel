import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Eye, Play, ExternalLink, Award, Newspaper, Image as ImageIcon } from "lucide-react";

export const Route = createFileRoute("/_app/gallery")({
  head: () => ({
    meta: [
      { title: "Gallery — Abel Worku's Work" },
      { name: "description", content: "Explore Abel Worku's portfolio of animations, designs, video edits, web projects, certificates and news." },
    ],
  }),
  component: Gallery,
});

type Item = { id: string; title: string; description: string | null; category: string; image_url: string; video_url: string | null; media_type: string; view_count: number; created_at: string };
type Cert = { id: string; title: string; issuer: string | null; year: string | null; image_url: string; link: string | null };
type News = { id: string; title: string; content: string | null; media_url: string | null; media_type: string | null; created_at: string };

const categories = ["all", "forex", "animation", "video", "design", "web", "other"];

function Gallery() {
  const [items, setItems] = useState<Item[]>([]);
  const [certs, setCerts] = useState<Cert[]>([]);
  const [news, setNews] = useState<News[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");
  const [selected, setSelected] = useState<Item | null>(null);
  const { user } = useAuth();

  useEffect(() => {
    const load = async () => {
      const [g, c, n] = await Promise.all([
        supabase.from("gallery_items").select("*").order("created_at", { ascending: false }),
        supabase.from("certificates").select("*").order("created_at", { ascending: false }),
        supabase.from("news_posts").select("*").order("created_at", { ascending: false }),
      ]);
      setItems((g.data || []) as Item[]);
      setCerts((c.data || []) as Cert[]);
      setNews((n.data || []) as News[]);
      setLoading(false);
    };
    load();
    const ch = supabase.channel("gallery-all")
      .on("postgres_changes", { event: "*", schema: "public", table: "gallery_items" }, load)
      .on("postgres_changes", { event: "*", schema: "public", table: "certificates" }, load)
      .on("postgres_changes", { event: "*", schema: "public", table: "news_posts" }, load)
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, []);

  const filtered = filter === "all" ? items : items.filter((i) => i.category === filter);

  const openItem = async (item: Item) => {
    setSelected(item);
    let age: number | null = null;
    if (user) {
      const { data } = await supabase.from("profiles").select("age").eq("id", user.id).maybeSingle();
      age = data?.age ?? null;
    }
    await supabase.rpc("increment_gallery_view", {
      _item_id: item.id, _viewer_id: (user?.id ?? null) as any, _viewer_age: (age ?? null) as any,
    });
  };

  return (
    <div className="container mx-auto px-6 py-16 md:py-24">
      <div className="text-center mb-10">
        <p className="text-sm uppercase tracking-[0.3em] text-gold mb-4">Gallery</p>
        <h1 className="font-display text-5xl md:text-6xl font-bold">My <span className="text-gradient-gold">Work</span></h1>
        <p className="mt-4 text-muted-foreground max-w-xl mx-auto">A curated collection of work, certificates and news.</p>
      </div>

      <Tabs defaultValue="works" className="max-w-6xl mx-auto">
        <TabsList className="mx-auto flex w-fit">
          <TabsTrigger value="works"><ImageIcon className="h-4 w-4 mr-1" />Works</TabsTrigger>
          <TabsTrigger value="certs"><Award className="h-4 w-4 mr-1" />Certificates</TabsTrigger>
          <TabsTrigger value="news"><Newspaper className="h-4 w-4 mr-1" />News</TabsTrigger>
        </TabsList>

        <TabsContent value="works" className="pt-8">
          <div className="flex flex-wrap justify-center gap-2 mb-10">
            {categories.map((c) => (
              <button key={c} onClick={() => setFilter(c)}
                className={`px-4 py-2 rounded-full text-xs uppercase tracking-wider transition-colors ${filter === c ? "gradient-gold text-primary-foreground" : "glass hover:border-gold/40"}`}>{c}</button>
            ))}
          </div>
          {loading ? <div className="text-center text-muted-foreground py-20">Loading...</div> :
            filtered.length === 0 ? <div className="text-center py-20 glass rounded-2xl"><p className="font-display text-2xl mb-2">No items yet</p></div> :
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {filtered.map((item) => (
                <button key={item.id} onClick={() => openItem(item)}
                  className="group relative aspect-square rounded-xl overflow-hidden glass hover:border-gold/40 transition-all">
                  {item.media_type === "video" && item.video_url ? (
                    <>
                      <video src={item.video_url} className="w-full h-full object-cover" muted />
                      <div className="absolute inset-0 flex items-center justify-center bg-black/30 group-hover:bg-black/10 transition-colors">
                        <Play className="h-12 w-12 text-gold drop-shadow-lg" fill="currentColor" />
                      </div>
                    </>
                  ) : (
                    <img src={item.image_url} alt={item.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-4">
                    <p className="font-display text-sm text-gold uppercase tracking-wider">{item.category}</p>
                    <p className="font-display text-lg">{item.title}</p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1"><Eye className="h-3 w-3" /> {item.view_count}</p>
                  </div>
                </button>
              ))}
            </div>}
        </TabsContent>

        <TabsContent value="certs" className="pt-8">
          {certs.length === 0 ? <div className="text-center py-20 glass rounded-2xl"><p className="text-muted-foreground">No certificates yet.</p></div> :
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {certs.map((c) => (
                <div key={c.id} className="glass rounded-2xl overflow-hidden group hover:border-gold/40 transition-colors">
                  <img src={c.image_url} alt={c.title} className="w-full aspect-video object-cover group-hover:scale-105 transition-transform duration-500" />
                  <div className="p-5">
                    <p className="font-display text-lg">{c.title}</p>
                    <p className="text-xs text-muted-foreground mt-1">{c.issuer}{c.year && ` · ${c.year}`}</p>
                    {c.link && <a href={c.link} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 mt-3 text-xs text-gold hover:underline">Verify <ExternalLink className="h-3 w-3" /></a>}
                  </div>
                </div>
              ))}
            </div>}
        </TabsContent>

        <TabsContent value="news" className="pt-8">
          {news.length === 0 ? <div className="text-center py-20 glass rounded-2xl"><p className="text-muted-foreground">No news yet.</p></div> :
            <div className="grid md:grid-cols-2 gap-6">
              {news.map((n) => (
                <article key={n.id} className="glass rounded-2xl overflow-hidden">
                  {n.media_url && (n.media_type === "video"
                    ? <video src={n.media_url} controls className="w-full aspect-video object-cover" />
                    : <img src={n.media_url} alt={n.title} className="w-full aspect-video object-cover" />)}
                  <div className="p-5">
                    <p className="font-display text-xl">{n.title}</p>
                    <p className="text-xs text-muted-foreground mt-1">{new Date(n.created_at).toLocaleDateString()}</p>
                    {n.content && <p className="text-sm mt-3 whitespace-pre-wrap">{n.content}</p>}
                  </div>
                </article>
              ))}
            </div>}
        </TabsContent>
      </Tabs>

      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-w-3xl">
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle className="font-display text-2xl text-gradient-gold">{selected.title}</DialogTitle>
              </DialogHeader>
              {selected.media_type === "video" && selected.video_url
                ? <video src={selected.video_url} controls autoPlay className="w-full rounded-lg" />
                : <img src={selected.image_url} alt={selected.title} className="w-full rounded-lg" />}
              <p className="text-xs uppercase tracking-wider text-gold">{selected.category}</p>
              {selected.description && <p className="text-muted-foreground">{selected.description}</p>}
              <p className="text-xs text-muted-foreground flex items-center gap-1"><Eye className="h-3 w-3" /> {selected.view_count} views</p>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
