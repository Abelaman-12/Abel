import { Outlet, createRootRoute, HeadContent, Scripts, Link } from "@tanstack/react-router";
import appCss from "../styles.css?url";
import { AuthProvider } from "@/hooks/useAuth";
import { Toaster } from "@/components/ui/sonner";

function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="text-center">
        <h1 className="font-display text-8xl text-gradient-gold">404</h1>
        <p className="mt-4 text-muted-foreground">This page doesn't exist.</p>
        <Link to="/" className="inline-block mt-6 px-6 py-2 rounded-md gradient-gold text-primary-foreground font-medium">Go home</Link>
      </div>
    </div>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Abel Worku — Forex Trader, Animator, Editor & Designer" },
      { name: "description", content: "Portfolio of Abel Worku — Forex trader, stickman animator, video editor, graphic designer, and web developer." },
      { property: "og:title", content: "Abel Worku — Forex Trader, Animator, Editor & Designer" },
      { property: "og:description", content: "Portfolio of Abel Worku — Forex trader, stickman animator, video editor, graphic designer, and web developer." },
      { name: "twitter:title", content: "Abel Worku — Forex Trader, Animator, Editor & Designer" },
      { name: "twitter:description", content: "Portfolio of Abel Worku — Forex trader, stickman animator, video editor, graphic designer, and web developer." },
      { property: "og:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/zv35vyprfsMxj7qXDyAd89WbOBl1/social-images/social-1777640406383-abel-profile-Bf39jhuq.webp" },
      { name: "twitter:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/zv35vyprfsMxj7qXDyAd89WbOBl1/social-images/social-1777640406383-abel-profile-Bf39jhuq.webp" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:type", content: "website" },
    ],
    links: [{ rel: "stylesheet", href: appCss }],
  }),
  shellComponent: ({ children }) => (
    <html lang="en" className="dark">
      <head><HeadContent /></head>
      <body>{children}<Scripts /></body>
    </html>
  ),
  component: () => (
    <AuthProvider>
      <Outlet />
      <Toaster />
    </AuthProvider>
  ),
  notFoundComponent: NotFound,
});
